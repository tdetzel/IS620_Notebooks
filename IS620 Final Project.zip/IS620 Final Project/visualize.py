import networkx as net
import matplotlib.pyplot as plt

from collections import defaultdict
import math

twitter_network = [ line.strip().split('\t') for line in file('twitter_network.csv') ]

o = net.DiGraph()
hfollowers = defaultdict(lambda: 0)
for (twitter_user, followed_by, followers) in twitter_network:
    o.add_edge(twitter_user, followed_by, followers=int(followers))
    hfollowers[twitter_user] = int(followers)

SEED = 'realDonaldTrump'

# centre around the SEED node and set radius of graph
g = net.DiGraph(net.ego_graph(o, SEED, radius=4))

def trim_degrees_trump(g, degree=10, trump_degree=1):
    g2 = g.copy()
    d = net.degree(g2)
    for n in g2.nodes():
        if n == SEED: continue # don't prune the SEED node
        if d[n] <= degree and n.lower().find('trump') != -1:
            g2.remove_node(n)
        elif n.lower().find('trump') == -1 and d[n] <= trump_degree:
            g2.remove_node(n)
    return g2

def trim_edges_trump(g, weight=1, trump_weight=10):
    g2 = net.DiGraph()
    for f, to, edata in g.edges_iter(data=True):
        if f == SEED or to == SEED: # keep edges that link to the SEED node
            g2.add_edge(f, to, edata)
        elif f.lower().find('trump') != -1 or to.lower().find('trump') != -1:
            if edata['followers'] >= trump_weight:
                g2.add_edge(f, to, edata)
        elif edata['followers'] >= weight:
            g2.add_edge(f, to, edata)
    return g2

print 'g: ', len(g)
core = trim_degrees_trump(g, degree=235, trump_degree=2)
print 'core after node pruning: ', len(core)
# core = trim_edges_trump(core, weight=250000, trump_weight=35000)
core = trim_edges_trump(core, weight=400000, trump_weight=10)
print 'core after edge pruning: ', len(core)

# nodeset_types = { 'TED': lambda s: s.lower().startswith('ted'), 'Not TED': lambda s: not s.lower().startswith('ted') }
nodeset_types = { 'Trump': lambda s: s.lower().find('trump') != -1, 'Not Trump': lambda s: s.lower().find('trump') == -1 }

nodesets = defaultdict(list)

for nodeset_typename, nodeset_test in nodeset_types.iteritems():
    nodesets[nodeset_typename] = [ n for n in core.nodes_iter() if nodeset_test(n) ]

pos = net.spring_layout(core,k=0.20,iterations=20) # compute layout

colours = ['red','green']
colourmap = {}

plt.figure(figsize=(20,20))
plt.axis('off')

# draw nodes
i = 0
alphas = {'Trump': 0.7, 'Not Trump': 0.4}
for k in nodesets.keys():
    ns = [ math.log10(hfollowers[n]+1) * 600 for n in nodesets[k] ]
    print k, len(ns)
    net.draw_networkx_nodes(core, pos, nodelist=nodesets[k], node_size=ns, node_color=colours[i], alpha=alphas[k])
    colourmap[k] = colours[i]
    i += 1
print 'colourmap: ', colourmap

# draw edges
net.draw_networkx_edges(core, pos, width=0.7, alpha=0.5)

# draw labels
alphas = { 'Trump': 1.0, 'Not Trump': 0.5}
for k in nodesets.keys():
    for n in nodesets[k]:
        x, y = pos[n]
        plt.text(x, y+0.02, s=n, alpha=alphas[k], horizontalalignment='center', fontsize=14)
